var createBrowserHistory = require("history").createBrowserHistory

export default createBrowserHistory({});
